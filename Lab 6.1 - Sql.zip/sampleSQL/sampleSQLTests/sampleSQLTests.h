//
//  sampleSQLTests.h
//  sampleSQLTests
//
//  Created by MSE on 26/09/13.
//  Copyright (c) 2013 MSE. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface sampleSQLTests : SenTestCase

@end

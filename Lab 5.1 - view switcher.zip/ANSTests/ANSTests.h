//
//  ANSTests.h
//  ANSTests
//
//  Created by MSE on 19/09/13.
//  Copyright (c) 2013 MSE. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface ANSTests : SenTestCase

@end
